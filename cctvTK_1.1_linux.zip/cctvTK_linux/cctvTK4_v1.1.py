import cv2

error_code = False
file_path = 'data/file.txt'

config_path = 'data/config.txt'
try:
    with open(file_path, 'r') as file:
        lines = file.readlines() 
    lines = [line.strip() for line in lines]
    if lines[0] == "username" and lines[6] == "if u have the url enter Camera url replacing this line":
        error_code = True
    else:
        error_code = False
except:
    data = [
        f"username\n",
        f"password\n",
        f"ip\n",
        f"port\n",
        f"channel\n",
        f"subtype\n",
        f"if u have the url enter Camera url replacing this line\n"
        f"Enter your details of your camera in the above format\n"
        ]
    with open(file_path, 'w') as file:
        file.writelines(data)
        pass
    error_code =True
    lines = [[0],[0]]
try:
    with open(config_path, 'r') as file:
        lines_con = file.readlines()  # Read all lines into a list
    lines_con = [line.strip() for line in lines_con]
    line_number = int(lines_con[0])
except:
    line_number = 0
    with open(config_path, 'w') as file:
        pass
    lines_con = [[0],[0]]
if (not error_code):
    username = str(lines[0])
    password = str(lines[1])
    ip = str(lines[2])
    port = str(lines[3])
    channel = str(lines[4])
    subtype = str(lines[5])
    if str(lines[6]) != "if u have the url enter Camera url replacing this line":
        CAM1_URL = str(lines[6])
    else:
        CAM1_URL = f"rtsp://{username}:{password}@{ip}:{port}/cam/realmonitor?channel={channel}&subtype={subtype}"
else:
    print("Enter Camera url details in the file.txt in the data Folder")
line34_act = False




if(line_number == 0):
    line1_Points = [[0, 0], [0, 0]]
    line2_Points = [[0, 0], [0, 0]]
    line3_Points = [[0, 0], [0, 0]]
    line4_Points = [[0, 0], [0, 0]]
    line_thickness = 5
if(line_number == 1):#coz if zero ther
    print("2 line mode")
    k=1
    line1_Points = [[int(lines_con[k]),int(lines_con[k+1])],[int(lines_con[k+2]),int(lines_con[k+3])]]
    line_thickness = int(lines_con[5])
    k=6
    line2_Points = [[int(lines_con[k]),int(lines_con[k+1])],[int(lines_con[k+2]),int(lines_con[k+3])]]
else:
    if(line_number == 2):
        print("4 line mode")
        line34_act = True
        k=1
        line1_Points = [[int(lines_con[k]),int(lines_con[k+1])],[int(lines_con[k+2]),int(lines_con[k+3])]]
        line_thickness = int(lines_con[5])
        k=6
        line2_Points = [[int(lines_con[k]),int(lines_con[k+1])],[int(lines_con[k+2]),int(lines_con[k+3])]]
        k=11
        line3_Points = [[int(lines_con[k]),int(lines_con[k+1])],[int(lines_con[k+2]),int(lines_con[k+3])]]
        k=16
        line4_Points = [[int(lines_con[k]),int(lines_con[k+1])],[int(lines_con[k+2]),int(lines_con[k+3])]]
    else:

        line1_Points = [[0, 0], [0, 0]]
        line2_Points = [[0, 0], [0, 0]]
        line3_Points = [[0, 0], [0, 0]]
        line4_Points = [[0, 0], [0, 0]]
        line_thickness = 5
        line_number = 1
"""line1_Points = [[0, 0], [0, 0]]
line2_Points = [[0, 0], [0, 0]]"""
press_state = False
line_state = False
reset = False
save_state = False
state2 = False
state3 = False
def setLine1(x1, x2):
    global line1_Points
    line1_Points = (x1, x2)

def setLine2(x1, x2):
    global line2_Points
    line2_Points = (x1, x2)

def getpos_mouse_down(event, x, y, flags, param):
    global mouseX, mouseY, press_state, line1_Points, line2_Points,line3_Points, line4_Points
    global line_state 
    global reset
    global save_state
    global line_number
    global state2
    global line34_act
    global line_thickness
    global state3
    if reset == True:
        line1_Points = [[0, 0], [0, 0]]
        line2_Points = [[0, 0], [0, 0]]
        press_state = False
        state2 = False
        line_state = False
        reset = False
        state3 = False
    if event == cv2.EVENT_LBUTTONDBLCLK and not press_state and line_state == False and state2 == False:
        mouseX, mouseY = x, y
        pos = [x,y]
        line1_Points[0] = pos
        line1_Points[1] = pos
        press_state = True
        #print("1")

    elif event == cv2.EVENT_LBUTTONDBLCLK and press_state and line_state == False and reset == False and state2 == False:
        mouseX, mouseY = x, y
        pos = [x,y]
        line1_Points[1] = pos
        press_state = False
        line_state = True
        #print("2")

    elif event == cv2.EVENT_LBUTTONDBLCLK and not press_state and line_state == True and reset == False and state2 == False:
        mouseX, mouseY = x, y
        pos = [x,y]
        line2_Points[0] = pos
        line2_Points[1] = pos
        press_state = True
        #print("3")

    elif event == cv2.EVENT_LBUTTONDBLCLK and press_state and line_state == True and reset == False and state2 == False:
        mouseX, mouseY = x, y
        pos = [x,y]
        line2_Points[1] = pos
        #print("4")
        press_state = False
        if not line34_act:
            line_state = False
            save_state = True
        else:
            state2 = True

    elif event == cv2.EVENT_LBUTTONDBLCLK and not press_state and line_state == True and reset == False and line34_act and state2 == True and not state3:
        mouseX, mouseY = x, y
        pos = [x,y]
        line3_Points[0] = pos
        line3_Points[1] = pos
        press_state = True
        #print("5")

    elif event == cv2.EVENT_LBUTTONDBLCLK and press_state and line_state == True and reset == False and line34_act and state2 == True and not state3:
        mouseX, mouseY = x, y
        pos = [x,y]
        line3_Points[1] = pos
        press_state = False
        state3 = True
        #print("6")
    elif event == cv2.EVENT_LBUTTONDBLCLK and not press_state and line_state == True and reset == False and line34_act and state2 == True and  state3:
        mouseX, mouseY = x, y
        pos = [x,y]
        line4_Points[0] = pos
        line4_Points[1] = pos
        press_state = True
        #print("7")

    elif event == cv2.EVENT_LBUTTONDBLCLK and press_state and line_state == True and reset == False and line34_act and state2 == True and  state3:
        mouseX, mouseY = x, y
        pos = [x,y]
        line4_Points[1] = pos
        press_state = False
        line_state = False
        save_state = True
        state2 = False
        state3 = False
        #print("8")
    

    
if __name__ == "__main__" and not error_code:
    VideoCapture = cv2.VideoCapture(CAM1_URL)
    vis = True
    cv2.namedWindow("window", cv2.WND_PROP_FULLSCREEN)
    cv2.setWindowProperty("window", cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)
    cv2.setMouseCallback("window", getpos_mouse_down)
    while True:
        ret, frame = VideoCapture.read()
        if not ret:
            print("Failed to capture image")
            break
        
        if line34_act:
            cv2.line(img=frame, pt1=line1_Points[0], pt2=line1_Points[1], color=(0, 0, 255), thickness=line_thickness,lineType=8,shift=0)
            cv2.line(img=frame, pt1=line2_Points[0], pt2=line2_Points[1], color=(0, 0, 255), thickness=line_thickness,lineType=8,shift=0)
            cv2.line(img=frame, pt1=line3_Points[0], pt2=line3_Points[1], color=(0, 165, 255), thickness=line_thickness,lineType=8,shift=0)
            cv2.line(img=frame, pt1=line4_Points[0], pt2=line4_Points[1], color=(0, 165, 255), thickness=line_thickness,lineType=8,shift=0)
        else:
            cv2.line(img=frame, pt1=line1_Points[0], pt2=line1_Points[1], color=(0, 0, 255), thickness=line_thickness,lineType=8,shift=0)
            cv2.line(img=frame, pt1=line2_Points[0], pt2=line2_Points[1], color=(0, 0, 255), thickness=line_thickness,lineType=8,shift=0)
        if(save_state == True):
            save_state = False
            line1_x1, line1_y1 = line1_Points[0]
            line1_x2, line1_y2 = line1_Points[1]
            line2_x1, line2_y1 = line2_Points[0]
            line2_x2, line2_y2 = line2_Points[1]
            data = [
                f"1\n",  # Number of lines
                f"{line1_x1}\n", f"{line1_y1}\n", f"{line1_x2}\n", f"{line1_y2}\n",f"{line_thickness}\n",  # Line 1 info
                f"{line2_x1}\n", f"{line2_y1}\n", f"{line2_x2}\n", f"{line2_y2}\n", f"{line_thickness}\n",   # Line 2 info
                f"0\n", f"0\n", f"0\n", f"0\n", f"{line_thickness}\n",  # Line 3 info
                f"0\n", f"0\n", f"0\n", f"0\n", f"0\n"   # Line 4 info   
            ]
            if(line34_act):
                line3_x1, line3_y1 = line3_Points[0]
                line3_x2, line3_y2 = line3_Points[1]
                line4_x1, line4_y1 = line4_Points[0]
                line4_x2, line4_y2 = line4_Points[1]
                data = [
                    f"2\n",
                    f"{line1_x1}\n", f"{line1_y1}\n", f"{line1_x2}\n", f"{line1_y2}\n", f"{line_thickness}\n",  # Line 1 info
                    f"{line2_x1}\n", f"{line2_y1}\n", f"{line2_x2}\n", f"{line2_y2}\n", f"{line_thickness}\n",  # Line 2 info
                    f"{line3_x1}\n", f"{line3_y1}\n", f"{line3_x2}\n", f"{line3_y2}\n", f"{line_thickness}\n",  # Line 3 info
                    f"{line4_x1}\n", f"{line4_y1}\n", f"{line4_x2}\n", f"{line4_y2}\n", f"{line_thickness}\n"   # Line 4 info       
                ]
            with open(config_path, 'w') as file:
                file.writelines(data)
            
        input1 = cv2.waitKey(1) 
        if input1 > 1 or error_code:
            if input1 & 0xFF == ord('r'):
                print("points reset")
                line1_Points = [[0, 0], [0, 0]]
                line2_Points = [[0, 0], [0, 0]]
                line3_Points = [[0, 0], [0, 0]]
                line4_Points = [[0, 0], [0, 0]]
                line_thickness = 5
                reset = True
            if input1 & 0xFF == 43 and line_thickness <= 50:# + is  pressed
                line_thickness += 1
                save_state = True
            if input1 & 0xFF == 45 and line_thickness > 1:# - is pressed
                line_thickness -= 1
                save_state = True
            if input1 & 0xFF == 27 or error_code:#esc key
                break
        
        cv2.imshow('window', frame)

        

    VideoCapture.release()
    cv2.destroyAllWindows()
